<?php
require_once __DIR__.'/blade.php';
require_once __DIR__.'/path.php';
require_once __DIR__.'/file.php';
require_once __DIR__.'/any.php';