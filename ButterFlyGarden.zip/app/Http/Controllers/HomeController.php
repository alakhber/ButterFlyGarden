<?php

namespace App\Http\Controllers;

use App\Http\Requests\Project\FrontEnd\Subscription\StoreSubscriptionRequest;
use App\Http\Requests\SendContactMailRequest;
use App\Mail\ContactMail;
use App\Models\Blog;
use App\Models\Product;
use App\Models\Project;
use App\Models\Service;
use App\Models\Slider;
use App\Models\Subscription;
use Illuminate\Support\Facades\Mail;

class HomeController extends Controller
{
    public function index()
    {
        $sendData = [
            'sliders' => Slider::whereStatus(1)->orderBy('position')->get(),
            'blogs' => Blog::whereStatus(1)->limit(4)->get(),
            'services' => Service::whereStatus(1)->limit(4)->get(),
            'products' => Product::with(['detail', 'category'])->whereStatus(1)->limit(4)->get(),
        ];
        return view('main.pages.index', $sendData);
    }

    public function services()
    {
        $sendData = [
            'services' => Service::whereStatus(1)->orderBy('position')->paginate(9),
        ];
        return view('main.pages.services', $sendData);
    }
    
    public function products()
    {
        $sendData = [
            'products' => Product::whereStatus(1)->with('category')->paginate(9),
        ];
        return view('main.pages.products', $sendData);
    }

    public function product($slug)
    {
        $product = Product::whereStatus(1)->whereSlug($slug)->firstOrFail();
        $sendData = [
            'product' => $product,
            'products'=>Product::where('id','!=',$product->id)->whereStatus(1)->limit(5)->get(),
        ];
        return view('main.pages.product', $sendData);
    }


    public function service($slug)
    {
        $service = Service::whereStatus(1)->whereSlug($slug)->firstOrFail();
        
        $sendData = [
            'service' => $service,
            'services'=>Service::where('id','!=',$service->id)->whereStatus(1)->limit(5)->get(),
        ];
        return view('main.pages.service', $sendData);
    }

    public function blogs()
    {


        $sendData = [
            'recentBlogs' => Blog::whereStatus(1)->limit(4)->get(),
            'blogs' => Blog::whereStatus(1)->paginate(4),
        ];

        return view('main.pages.blogs', $sendData);
    }


    public function blog($slug){
        $blog = Blog::whereSlug($slug)->whereStatus(1)->firstOrFail();
        
        $sendData = [
            'blog'=>$blog,
            'latestBlogs'=>Blog::where('id','!=',$blog->id)->whereStatus(1)->limit(5)->orderBy('id','DESC')->get(),
        ];

        return view('main.pages.blog', $sendData);
        
    }

    public function subscription(StoreSubscriptionRequest $request)
    {
        try {
            $request= $request->validated();
            Subscription::create($request);

            dd('ok');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public function contact(){
        return view('main.pages.contact');
    }

    public function projects(){
        $projects = Project::whereStatus(true)->paginate(4);
        $sendData = [
            'projects'=>$projects
        ];
        return view('main.pages.projects',$sendData);
    }
    public function project($slug){
        $project = Project::whereSlug($slug)->first();
        
        $sendData = [
            'project'=>$project
        ];
        return view('main.pages.project',$sendData);
    }

    public function contactMail(SendContactMailRequest $request)
    {
        Mail::send(new ContactMail($request->validated()));
        
        return redirect()->route('index')->with('sent', __('admin.mail-thanks'));
    }
}
