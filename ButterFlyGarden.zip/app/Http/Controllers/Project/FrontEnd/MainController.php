<?php

namespace App\Http\Controllers\Project\FrontEnd;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MainController extends Controller
{
    //
}
