<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="{{ _adminCss('icons/icomoon/styles.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ _adminCss('icons/fontawesome/styles.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{ _adminCss('all.min.css') }}" rel="stylesheet" type="text/css">
@yield('_styles')