<head>
    <meta charset="UTF-8">
    <title>{{ _setting('main_title') }} @yield('_title')</title>
    <meta name="author" content="Alakhber Nakhiyev">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   @include('main.partials._styles')
</head>