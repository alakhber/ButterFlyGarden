<div class="preloader">
    <div class="clear-loading loading-effect-2">
        <span></span>
    </div>
</div>