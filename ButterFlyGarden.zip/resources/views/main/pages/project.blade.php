@extends('layouts.main')
@section('_title')
    | {{ $project->name }}
@endsection
@section('_content')
    <div class="page-title">
        <div class="container-fluid">
            <div class="row">
                <div class="inner-title">
                    <div class="overlay-image"></div>
                    <div class="banner-title">
                        <div class="page-title-heading">
                            {{ $project->name }}
                        </div>
                        <div class="page-title-content link-style6">
                            <span><a class="home" href="{{ route('home') }}">Ana Səhifə</a></span>
                            <span><a class="home" href="{{ route('projects') }}">Lahiyələr</a></span>
                            <span class="page-title-content-inner">{{ $project->name }}</span>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.page-title -->

    <section class="flat-case-details">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="section-heading-jost-size46 fw-500 text-pri2-color center mg-bottom-50 ">{{ $project->name }}</h3>
                    <div class="post-case-details" style="width: 100%;height: 500px;">
                        <img style="width: 100%;height: 100%; object-fit: contain" src="{{ _img($project->avatar) }}" alt="{{ $project->name }}">
                    </div>
                </div>
                {{-- <div class="col-md-6">
                    <div class="services-box mg-bottom-35 wow fadeInLeft">
                        <div class="features-box">
                            <span class="tf-icon icon-Group-660"><span class="ripple"></span></span>
                            <div class="content-features">
                                <a href="#">
                                    <h3 class="section-heading-jost-size28 mg-bottom-8">Company Gather.</h3>
                                </a>
                                <p class="section-desc">Lorem Ipsum is simply dummy available typesetting industry been the industry standard Lorem Ipsum</p>
                            </div>
                        </div>
                        <div class="post-inner-box">
                            <img src="images/services/close-up-planting-flowers-pot.jpg" alt="images">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="services-box mg-bottom-35 wow fadeInLeft">
                        <div class="features-box">
                            <span class="tf-icon icon-admin-sys"><span class="ripple"></span></span>
                            <div class="content-features">
                                <a href="#">
                                    <h3 class="section-heading-jost-size28 mg-bottom-8">Company Details. </h3>
                                </a>
                                <p class="section-desc">Lorem Ipsum is simply dummy text free available typesetting industry been the industry simply </p>
                            </div>
                        </div>
                        <div class="post-inner-box">
                            <img src="images/services/portrait-smiling-young-woman-holding-colorful-petunias-wooden-crate.jpg" alt="images">
                        </div>
                    </div>
                </div> --}}

                <div class="col-md-12 " style="color: #000 !important">
                  {!! $project->content !!}
                    <div class="themesflat-spacer clearfix" data-desktop="75" data-mobile="30" data-smobile="30"></div>
                </div>
                {{-- <div class="col-md-3">
                    <div class="author-post">
                        <img src="images/services/portrait-woman-gardening.jpg" alt="images">
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="author-note bd-radius-8">
                        <h4 class="author-name section-heading-rubik-size16 fw-500 text-pri2-color">D.JHON SHIKON</h4>
                        <p class="author-desc">Lorem Ipsum is simply dummy text of free available in market the printing and typesetting industry has been the industry's standard dummy text ever.</p>
                    </div>
                </div> --}}
                {{-- <div class="col-md-12">
                    <div class="post-tags-socials">
                        <div class="post-tags">
                            <span class="section-heading-rubik-size18 text-pri-color mg-right-15">Tag:</span>
                            <a class="section-heading-rubik-size12 fw-500" href="#">design</a>
                            <a class="section-heading-rubik-size12 fw-500" href="#">ui/ux design</a>
                            <a class="section-heading-rubik-size12 fw-500" href="#">graphics</a>
                            <a class="section-heading-rubik-size12 fw-500" href="#">icon</a>
                        </div>
                        <div class="post-socials ">
                            <a href="#" class="skype"><span class="fa fa-skype"></span></a>
                            <a href="#" class="facebook"><span class="fa fa-facebook"></span></a>
                            <a href="#" class="instagram"><span class="fa fa-instagram"></span></a>
                            <a href="#" class="twitter"><span class="fa fa-twitter"></span></a>
                        </div>
                    </div>
                </div> --}}
            </div>
        </div>
    </section>
@endsection
