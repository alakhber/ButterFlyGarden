
<?php $__env->startSection('_content'); ?>
    <!-- page title -->
    <div class="page-title-home1">
        <!-- slider -->
        <div class="container">
            <div class="row">
                <!-- <div class="overlay-image"></div> -->

                <div class="inner-title-home1">
                    <!-- /.page-title -->
                    <div class="flat-slider clearfix">
                        <div class="rev_slider_wrapper fullwidthbanner-container">
                            <div id="rev-slider2" class="rev_slider fullwidthabanner">
                                <ul>
                                    <!-- Slide 1 -->

                                    <!-- /End Slide 1 -->
                                    <!-- Slide 1 -->
                                    

                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <!-- Layers -->
                                            

                                            <?php if(!is_null($slider->content)): ?>
                                                <div class="tp-caption tp-resizeme text-two" data-x="['left','left','left','center']" data-hoffset="['-2','-2','5','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-130','-165', '-15','-15']" data-fontsize="['60','70','50','60']" data-lineheight="['70','80','64','48']" data-width="full" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];" data-mask_out="x:inherit;y:inherit;" data-start="700" data-splitin="none" data-splitout="none" data-responsive_offset="on">
                                                    <div class="title-box">
                                                        <h2 class="title-slider text-pri2-color"><?php echo $slider->content; ?></h2>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(!is_null($slider->link)): ?>
                                                <div class="tp-caption btn-text btn-linear hv-linear-gradient" data-x="['left','left','left','center']" data-hoffset="['-3','-3','5','0']" data-y="['middle','middle','middle','middle']" data-voffset="['48','40','180','280']" data-width="full" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];" data-mask_out="x:inherit;y:inherit;" data-start="700" data-splitin="none" data-splitout="none" data-responsive_offset="on">
                                                    <div class="button-box">
                                                        <div class="button res-btn-slider">
                                                            <a href="<?php echo e($slider->link); ?>" class="btn btn-left">
                                                                <?php if(!is_null($slider->button)): ?>
                                                                    <?php echo e($slider->button); ?>

                                                                <?php else: ?>
                                                                    Ətraflı
                                                                <?php endif; ?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="tp-caption tp-resizeme image-slider text-right " data-x="['right','right','right','right']" data-hoffset="['-29','-29','-150','-29']" data-y="['center','center','center','center']" data-voffset="['-88','-88','60','-88']" data-width="full" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" data-mask_in="x:0px;y:[100%];" data-mask_out="x:inherit;y:inherit;" data-start="800" data-splitin="none" data-splitout="none" data-responsive_offset="on">
                                                <img class="img-slide wow jackInTheBox" data-wow-delay="2500ms" data-wow-duration="3s" src="<?php echo e($slider->photo); ?>" alt="images">
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- /End Slide 1 -->
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- flat-slider -->
                </div>

            </div>

        </div>
        <!-- .slider -->

    </div>
    <!-- /.page-title -->

    <!-- about -->
    <section class="flat-about">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="121" data-mobile="60" data-smobile="60">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-post center bd-radius-50-image">
                        <img class="main-post-about" src="<?php echo e(_frontStaticImg('home/the-girl-in-the-glasses.jpg')); ?>" alt="images">
                        <img class="circel-inside" src="<?php echo e(_frontStaticImg('home/circle-about.png')); ?>" alt="images">
                        
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-content">
                        <div class="about-content-title wow fadeInUp">
                            <div class="section-subtitle">Haqqımızda</div>
                            <div class="section-title">Biz kimik?</div>
                            <div class="section-desc">Lorem Ipsum is simply dummy text of free available market
                                typesetting industry has been the industry's standard dummy text ever. Lorem Ipsum
                                is simply dummy text of free available </div>
                        </div>
                        <div id="about-box" class="about-desc-box">
                            
                            
                        </div>
                        <div class="button hover-up d-flex justify-content-end">
                            <a href="<?php echo e(route('contact')); ?>" class="btn2 d-block">Əlaqə</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /about -->

    <!-- Our services -->
    <section class="flat-services">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title-box">
                        
                        
                        <h2 class="section-title">Xidmətlərimiz</h2>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="67" data-mobile="60" data-smobile="60">
                    </div>
                </div>

                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-four-column">
                        <div class="our-services-box hover-up-style2 mg-bottom30 wow fadeInDown">
                            <div class="our-services-overlay"></div>
                            <span class="tf-icon icon-size icon-icon-farming-layer">
                                <img src="<?php echo e(_frontStaticImg('logo-150.png')); ?>" alt="">
                            </span>
                            <div class="content-features">
                                <a href="<?php echo e(route('service', $service->slug)); ?>">
                                    <h3 class="section-heading-jost-size22"><?php echo e($service->name); ?></h3>
                                </a>
                                <p class="section-desc">
                                    <?php echo e(substr($service->shortcontent, 0, 150)); ?>

                                </p>
                                <div class="link2 link-style2">
                                    <a href="<?php echo e(route('service', $service->slug)); ?>" class="read-more">
                                        Ətraflı
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section class="flat-shop">
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="margin-bottom: 50px;">
                    <div class="col-lg-8 col-sm-6">
                        <div class="section-title-box">
                            <h2 class="section-title">Məhsullarımız</h2>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="button-news mg-top-20">
                            <a href="product.html" class="button-style-2 btn-2 f-right">Hamısı</a>
                        </div>
                    </div>
                    <div class="themesflat-spacer clearfix" data-desktop="65" data-mobile="60" data-smobile="40">
                    </div>
                </div>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <ul class="tf-shop-item wow fadeInDown">

                            <li>
                                <div class="shop-item-box">
                                    <div class="product-labels labels-rounded">
                                        <span class="attribute-label product-label label-with-img">
                                            <img src="https://shop.pitomnik-sochi.ru/wp-content/uploads/2020/08/5.svg" title="5" alt="5">
                                        </span>
                                        <span class="attribute-label product-label label-with-img">
                                            <img src="https://shop.pitomnik-sochi.ru/wp-content/uploads/2020/09/06–08.svg" title="06-08-m" alt="06-08-m">
                                        </span>
                                        <span class="attribute-label product-label label-with-img">
                                            <img src="https://shop.pitomnik-sochi.ru/wp-content/uploads/2020/09/04-06.svg" title="04-06-m" alt="04-06-m">
                                        </span>
                                    </div>
                                    <div class="image-item">
                                        <img src="<?php echo e(_frontStaticImg('shop/item1.png')); ?>" alt="images">
                                        
                                    </div>
                                    <div class="content-item">
                                        <a href="<?php echo e(route('project', $product->slug)); ?>" class="section-heading-jost-size20"><?php echo e($product->name); ?></a>
                                        
                                    </div>
                                </div>
                                <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="25" data-smobile="15"></div>
                            </li>

                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="118" data-mobile="0" data-smobile="0">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /shop home2 -->

    <!-- counter-->
    <section class="flat-counter">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60">
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="counter-content-left wow fadeInLeft">
                        <img class="background-counter" src="<?php echo e(_frontStaticImg('Counter/the-man-working-tree.jpg')); ?>" alt="images">
                        <div class="content-left-box">
                            <h2 class="title-main">We are nice people with a lot of experience.</h2>
                            <p class="section-desc">Junk MTV quiz graced by fox whelps. Bawds jog, flick quartz, vex
                                nymphs. Waltz, bad nymph</p>
                        </div>
                    </div>
                    <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="30" data-smobile="30">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="counter-content-right themesflat-counter wow fadeInRight">
                        <div class="content-right-box mg-bottom30">
                            <span class="title-main white number" data-speed="1000" data-to="10" data-inviewport="yes">10</span><span class="title-main white">+</span>
                            <h3 class="section-heading-jost-size20 fw-600">Years of experience</h3>
                        </div>
                        <div class="content-right-box box-2 mg-bottom30">
                            <span class="title-main white number" data-speed="1500" data-to="95" data-inviewport="yes">95</span><span class="title-main white">K</span>
                            <h3 class="section-heading-jost-size20 fw-600">Happy Customers</h3>
                        </div>
                        <div class="content-right-box box-3">
                            <span class="title-main white number" data-speed="2000" data-to="100" data-inviewport="yes">100</span><span class="title-main white">%</span>
                            <h3 class="section-heading-jost-size20 mg-top-5 fw-600">Satisfaction</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="120" data-mobile="60" data-smobile="60">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /conter -->

    <!-- Our team -->
    
    <!-- /Our team -->

    <!-- blog -->
    <section class="flat-blog-home01">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-sm-6">
                    <div class="section-title-box">
                        <h2 class="section-title">Blog</h2>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div class="button-news mg-top-20">
                        <a href="<?php echo e(route('blogs')); ?>" class="button-style-2 btn-2 f-right">Bloglar</a>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="slide-blog-content">
                        <div class="owl-carousel owl-theme">

                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item wow fadeInUp">
                                    <div class="blog-item hover-up-style2">
                                        <div class="item-overlay"></div>
                                        <div class="item-box link">
                                            
                                            <div class="link-style6">
                                                <div class="content-info margin-top">
                                                    <br>
                                                    <br>
                                                    <br>
                                                </div>
                                                <a href="<?php echo e(route('blog',$blog->slug)); ?>" class="section-heading-jost-size20">
                                                    <?php echo e($blog->name); ?>

                                                </a>
                                            </div>
                                            <hr class="line-blog-item">
                                           
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="60" data-smobile="0">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /blog -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/pages/index.blade.php ENDPATH**/ ?>