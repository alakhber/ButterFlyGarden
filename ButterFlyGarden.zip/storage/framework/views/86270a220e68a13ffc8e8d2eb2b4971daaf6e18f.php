
<?php $__env->startSection('_title'); ?>
| <?php echo e($service->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('_content'); ?>
<!-- page title -->
<div class="page-title">
    <div class="container-fluid">
        <div class="row">
            <div class="inner-title">
                <div class="overlay-image"></div>
                <div class="banner-title">
                    <div class="page-title-heading">
                        <?php echo e($service->name); ?>

                    </div>
                    <div class="page-title-content link-style6">
                        <span><a class="home" href="<?php echo e(route('home')); ?>">Ana Səhifə</a></span> |
                        <span><a class="home" href="<?php echo e(route('services')); ?>">Xidmətlər</a></span>
                        <span class="page-title-content-inner"><?php echo e($service->name); ?></span>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
<!-- /.page-title -->

<section class="flat-service-details">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="themesflat-spacer clearfix" data-desktop="117" data-mobile="60" data-smobile="60"></div>
            </div>
            <div class="col-md-4">
                <div class="side-bar-services-details mg-bottom30">
                    <div class="widget-nav-tab">
                        <ul class="tab-service link-style5">
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a class="active" href="<?php echo e(route('service', $serv->slug)); ?>"><?php echo e($serv->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="widget-contact-services-details mg-bottom-25">
                    <div class="sidebar-title mg-bottom-25">
                        <h2 class="section-heading-jost-size28 text-pri2-color">Əlaqə</h2>
                    </div>
                    <ul class="widget-sidebar-contact-us text-pri2-color section-heading-rubik-size16">
                        <li><span class="icon-telephone">Tel:</span><span class="info-contact-us"><?php echo e(_contact('phone')); ?></span></li>
                        <li><span class="icon-email">Email:</span><span class="info-contact-us"><?php echo e(_contact('email')); ?></span></li>
                    </ul>
                </div>

                <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="30" data-smobile="30"></div>
            </div>
            <div class="col-md-8">
                <article class="content-service-details">
                    <div class="post-service-details bd-radius-8-image mg-bottom-45">
                        <img src="<?php echo e(_img($service->avatar)); ?>" alt="<?php echo e($service->name); ?>">
                    </div>
                    <h2 class="section-heading-jost-size34 text-pri2-color mg-bottom30"><?php echo e($service->name); ?></h2>
                    <div class="section-desc mg-bottom-20"><?php echo $service->content; ?></div>
                </article>
            </div>
            <div class="col-md-12">
                <div class="themesflat-spacer clearfix" data-desktop="172" data-mobile="100" data-smobile="60"></div>
            </div>
        </div>
    </div>
</section>
<!-- / Our service -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/pages/service.blade.php ENDPATH**/ ?>