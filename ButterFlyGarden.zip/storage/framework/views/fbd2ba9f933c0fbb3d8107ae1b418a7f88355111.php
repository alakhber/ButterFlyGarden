<script src="<?php echo e(_adminJs('main/jquery.min.js')); ?>"></script>
<script src="<?php echo e(_adminJs('main/bootstrap.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('_scripts'); ?>
<?php echo _alert(); ?>

<script type='text/javascript'>
    $(function() {
        $('.DELETEITEM').on('click',function(){
            console.log($(this).find('form').submit());
        })
        $('.LOGOUT').on('click',function(){
            console.log($(this).find('form').submit());
        })
        $('.CHANGESTATUS').on('change',function(){
            console.log($(this).next().submit())
        })
        $('.CHANGETYPE').on('click',function(){
            console.log($(this).find('form').submit())
        })
    })

    
</script>
<?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/_scripts.blade.php ENDPATH**/ ?>