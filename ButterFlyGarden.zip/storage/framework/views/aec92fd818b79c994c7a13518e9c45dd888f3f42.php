<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('control.partials.__styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/_head.blade.php ENDPATH**/ ?>