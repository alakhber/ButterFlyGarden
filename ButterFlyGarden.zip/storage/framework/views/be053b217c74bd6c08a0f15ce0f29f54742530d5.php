
<?php $__env->startSection('_title'); ?>
    | <?php echo e($project->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_content'); ?>
    <div class="page-title">
        <div class="container-fluid">
            <div class="row">
                <div class="inner-title">
                    <div class="overlay-image"></div>
                    <div class="banner-title">
                        <div class="page-title-heading">
                            <?php echo e($project->name); ?>

                        </div>
                        <div class="page-title-content link-style6">
                            <span><a class="home" href="<?php echo e(route('home')); ?>">Ana Səhifə</a></span>
                            <span><a class="home" href="<?php echo e(route('projects')); ?>">Lahiyələr</a></span>
                            <span class="page-title-content-inner"><?php echo e($project->name); ?></span>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.page-title -->

    <section class="flat-case-details">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3 class="section-heading-jost-size46 fw-500 text-pri2-color center mg-bottom-50 "><?php echo e($project->name); ?></h3>
                    <div class="post-case-details" style="width: 100%;height: 500px;">
                        <img style="width: 100%;height: 100%; object-fit: contain" src="<?php echo e(_img($project->avatar)); ?>" alt="<?php echo e($project->name); ?>">
                    </div>
                </div>
                

                <div class="col-md-12 " style="color: #000 !important">
                  <?php echo $project->content; ?>

                    <div class="themesflat-spacer clearfix" data-desktop="75" data-mobile="30" data-smobile="30"></div>
                </div>
                
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/pages/project.blade.php ENDPATH**/ ?>