<!-- top header -->
<div class="top-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col md-4">
                <div class="top-bar-left">
                    <p class="top-location"><?php echo e(_contact('address')); ?></p>
                </div>
            </div>
            <div class="col md-8">
                <div class="top-bar-right link-style3">
                    <a href="#" class="top-mail"><?php echo e(_contact('email')); ?></a>
                    <ul class="widgets-nav-social">
                        <li><a href="<?php echo e(_contact('facebook')); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="<?php echo e(_contact('twitter')); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="<?php echo e(_contact('linkedin')); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="<?php echo e(_contact('instagram')); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.top --><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/partials/_header.blade.php ENDPATH**/ ?>