<!-- Main navbar -->
<div class="navbar navbar-expand-lg navbar-dark bg-indigo navbar-static">
    <div class="d-flex flex-1 d-lg-none">
        <button data-target="#navbar-search" type="button" class="navbar-toggler" data-toggle="collapse">
            <i class="icon-search4"></i>
        </button>
        <button type="button" class="navbar-toggler sidebar-mobile-main-toggle">
            <i class="icon-transmission"></i>
        </button>
    </div>

    <div class="navbar-brand text-center text-lg-left">
        <a href="index.html" class="d-inline-block">
            <img src="<?php echo e(_adminStaticImg('logo_light.png')); ?>" class="d-none d-sm-block" alt="Logo">
            <img src="<?php echo e(_adminStaticImg('logo_icon_light.png')); ?>" class="d-sm-none" alt="Logo">
        </a>
    </div>

    

    
</div>
<!-- /main navbar --><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/_nav.blade.php ENDPATH**/ ?>