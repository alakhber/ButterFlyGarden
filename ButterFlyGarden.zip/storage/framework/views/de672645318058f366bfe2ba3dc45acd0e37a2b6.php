<div class="sidebar sidebar-light sidebar-main sidebar-expand-lg">
    <div class="sidebar-content">
        <div class="sidebar-section">
            <div class="sidebar-user-material">
                <div class="sidebar-section-body">
                    <div class="d-flex">
                        <div class="flex-1">
                            <button type="button" class="btn btn-outline-light border-transparent btn-icon btn-sm rounded-pill">
                                
                            </button>
                        </div>
                        <a href="#" class="flex-1 text-center"><img src="<?php echo e(_adminStaticImg('placeholders/placeholder.jpg')); ?>" class="img-fluid rounded-circle shadow-sm" width="80" height="80" alt=""></a>
                        <div class="flex-1 text-right">
                            <button type="button" class="btn btn-outline-light border-transparent btn-icon rounded-pill btn-sm sidebar-control sidebar-main-resize d-none d-lg-inline-flex">
                                <i class="icon-transmission"></i>
                            </button>

                            <button type="button" class="btn btn-outline-light border-transparent btn-icon rounded-pill btn-sm sidebar-mobile-main-toggle d-lg-none">
                                <i class="icon-cross2"></i>
                            </button>
                        </div>
                    </div>
                    <div class="text-center">
                        <h6 class="mb-0 text-white text-shadow-dark mt-3"><?php echo e(auth()->user()->fullname); ?></h6>
                        <span class="font-size-sm text-white text-shadow-dark"><?php echo e(auth()->user()->type); ?></span>
                    </div>
                </div>
                <div class="sidebar-user-material-footer">
                    <a href="#user-nav" class="d-flex justify-content-between align-items-center text-shadow-dark dropdown-toggle" data-toggle="collapse"><span>User menu</span></a>
                </div>
            </div>
            <div class="collapse border-bottom" id="user-nav">
                <ul class="nav nav-sidebar">
                    <li class="nav-item">
                        <a href="<?php echo e(route('system.user.profil')); ?>" class="nav-link">
                            <i class="icon-gear"></i>
                            <span>Hesab</span>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link LOGOUT">
                            <i class="icon-switch2"></i>
                            <span>Çıxış</span>
                            <form action="<?php echo e(route('logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                            </form>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="sidebar-section">
            <ul class="nav nav-sidebar" data-nav-type="accordion">
                <li class="nav-item-header"><div class="text-uppercase font-size-xs line-height-xs">Main</div> <i class="icon-menu" title="Main"></i></li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.home')); ?>" class="nav-link">
                        <i class="icon-home4"></i>
                        <span>
                            Ana Səhifə
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.product.index')); ?>" class="nav-link">
                        <i class="fas fa-box-open"></i>
                        <span>
                            Məhsullar
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.category.index')); ?>" class="nav-link">
                        <i class="icon-tree6"></i>
                        <span>
                            Kataloq
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.user.index')); ?>" class="nav-link">
                        <i class="fas fa-users"></i>
                        <span>
                            İstifadəçilər
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.blog.index')); ?>" class="nav-link">
                        <i class="fab fa-blogger-b"></i>
                        <span>
                            Blog
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.setting.index')); ?>" class="nav-link">
                        <i class="fas fa-cogs"></i>
                        <span>
                            Tənzimləmələr
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.project.index')); ?>" class="nav-link">
                        <i class="fas fa-lightbulb"></i>
                        <span>
                            Lahiyələr
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.service.index')); ?>" class="nav-link">
                        <i class="fas fa-cog"></i>
                        <span>
                            Xidmətlər
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.contact.index')); ?>" class="nav-link">
                        <i class="fas fa-address-card"></i>
                        <span>
                            Əlaqə
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.page.index')); ?>" class="nav-link">
                        <i class="fas fa-file"></i>
                        <span>
                            Səhifələr
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.partner.index')); ?>" class="nav-link">
                        <i class="fas fa-handshake"></i>
                        <span>
                            Partner
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.subscriptions.index')); ?>" class="nav-link">
                        <i class="fas fa-heart"></i>
                        <span>
                            İzləyicilər
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.image.index')); ?>" class="nav-link">
                        <i class="fas fa-images"></i>
                        <span>
                            Şəkillər
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.image.index')); ?>" class="nav-link">
                        <i class="fas fa-images"></i>
                        <span>
                            Our Team
                        </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('system.slider.index')); ?>" class="nav-link">
                        <i class="fas fa-images"></i>
                        <span>
                            Slider
                        </span>
                    </a>
                </li>
                
                
                
                
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/_left-side.blade.php ENDPATH**/ ?>