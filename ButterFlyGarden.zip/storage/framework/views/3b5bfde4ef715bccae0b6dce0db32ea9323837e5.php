<div class="search">
    <input type="text" class="search-input" placeholder="<?php echo e(__('translation::translation.search')); ?>" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
</div><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/vendor/translation/forms/search.blade.php ENDPATH**/ ?>