<!-- Global stylesheets -->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
<link href="<?php echo e(_adminCss('icons/icomoon/styles.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(_adminCss('icons/fontawesome/styles.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(_adminCss('all.min.css')); ?>" rel="stylesheet" type="text/css">
<?php echo $__env->yieldContent('_styles'); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/__styles.blade.php ENDPATH**/ ?>