<!-- footer -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="top-footer wow fadeInDown">
                    <div class="top-footer-left">
                        <div class="logo-footer1 text-center">
                            <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(_frontStaticImg('logo.png')); ?>" style="height: 120px !important" alt="images"></a>
                        </div>
                    </div>
                    <div class="top-footer-right">
                        <div class="footer-contact-info">
                            <div class="footer-info-item">
                                <div class="location">
                                    <div class="icon-location"></div>
                                    <div class="content-location">
                                        <div class="heading-16px-rubik"><?php echo e(_contact('address')); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-info-item">
                                <div class="phone-call">
                                    <div class="icon-phone-call"></div>
                                    <div class="content-phone-call">
                                        <div class="heading-16px-rubik" style="margin-top: 10px"><?php echo e(_contact('phone')); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="footer-info-items">
                                <div class="email">
                                    <div class="icon-email"></div>
                                    <div class="content-email">
                                        <div class="heading-16px-rubik" style="margin-top: 10px"><?php echo e(_contact('email')); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="list-footer wow fadeInUp">
                    <div class="footer-item">
                        <div class="widgets-about padding-top-listfooter">
                            <p class="heading-jost-20px">
                                Sosial Media
                            </p>
                            
                            <ul class="widgets-nav-social">
                                <li><a href="<?php echo e(_contact('facebook')); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e(_contact('twitter')); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e(_contact('instagram')); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                                <li><a href="<?php echo e(_contact('linkedin')); ?>"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="footer-item">
                        <div class="widgets-menu-1 padding-top-listfooter">
                            <p class="heading-jost-20px">
                                Səhifələr
                            </p>
                            <ul class="list-menu-1 text-decs link-style4">
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="#<?php echo e($page->slug); ?>"><?php echo e($page->name); ?></a> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="footer-item padding-top-listfooter">
                        <div class="widgets-menu-2">
                            <p class="heading-jost-20px">
                                Son Bloglar
                            </p>
                            <ul class="list-menu-2 text-decs link-style4">
                                <?php $__currentLoopData = $resendBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <h3 class="heading-menu2"><a href="<?php echo e(route('blog', $blog->slug)); ?>"><?php echo e($blog->name); ?></a></h3>
                                        
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="footer-item padding-top-listfooter">
                        <div class="widgets-subcribes">
                            <p class="heading-jost-20px">
                                Bizi İzləyin
                            </p>
                            
                            <div class="widgets-input-subcribes">
                                <form method="post" action="<?php echo e(route('subscription')); ?>" class="form-subcribe">
                                    <?php echo csrf_field(); ?>
                                    <input type="email" name="email" class="widgets-text-input" placeholder="Email Address" required>
                                    <button type="submit" class="fa fa-envelope"></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright link-style4">
                        <div class="col-lg-12">
                            <img style="display: block;
                            margin-left: auto;
                            margin-right: auto;
                            width: 100px;
                            margin-top:20px;
                            margin-bottom:20px;
                            " src="<?php echo e(_frontStaticImg('logo.png')); ?>" alt="">
                        </div>
                        <p class="copyright-text">

                            &copy; 2022 by ButterFlyGarden
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</footer>
<!-- / footer -->

<!-- btn go top -->
<div class="button-go-top">
    <a href="#" title="" class="go-top">
        <i class="fa fa-chevron-up"></i>
    </a>
</div>
<!-- / btn go top -->
<?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/partials/_footer.blade.php ENDPATH**/ ?>