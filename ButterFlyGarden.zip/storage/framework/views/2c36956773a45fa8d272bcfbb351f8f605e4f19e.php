<?php if($paginator->hasPages()): ?>
<ul>
            
            <?php if($paginator->onFirstPage()): ?>
                <li><a href="javascript:void(0)" class="page-numbers prev"><span class="fa fa-angle-left"></span></a></li>
            <?php else: ?>
                <li><a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-numbers prev"><span class="fa fa-angle-left"></span></a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li><a href="#" class="page-numbers"><?php echo e($element); ?></a></li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li><a href="#" class="page-numbers current"><?php echo e($page); ?></a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e($url); ?>" class="page-numbers"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li><a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-numbers next"><span class="fa fa-angle-right"></span></a></li>
            <?php else: ?>
                <li><a href="#" class="page-numbers next">  <span class="fa fa-angle-right"></span></a></li>
            <?php endif; ?>
        </ul>
<?php endif; ?>




<?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/vendor/pagination/bootstrap-4.blade.php ENDPATH**/ ?>