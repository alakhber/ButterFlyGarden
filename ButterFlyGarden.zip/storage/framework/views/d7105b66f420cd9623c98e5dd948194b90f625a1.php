
<?php $__env->startSection('_title'); ?>
| Bloglar
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_content'); ?>
<div class="page-title">
    <div class="container-fluid">
        <div class="row">
            <div class="inner-title">
                <div class="overlay-image"></div>
                <div class="banner-title">
                    <div class="page-title-heading">
                        Bloglar
                    </div>
                    <div class="page-title-content link-style6">
                        <span><a class="home" href="<?php echo e(route('home')); ?>">Ana Səhifə</a></span> |
                        <span><a class="home" href="<?php echo e(route('blogs')); ?>">Bloglar</a></span>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>
    <!-- main content -->
    <section class="flat-blog-standard">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="47" data-mobile="0" data-smobile="0"></div>
                </div>
                <div class="col-md-8">
                    <div class="post-wrap">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="article-1">
                                <div class="image-box">
                                    <div class="image" style="width: 100%;height: 500px;">
                                        <img style="width: 100%;height: 100%; object-fit: cover" src="<?php echo e(_img($blog->avatar)); ?>" alt="<?php echo e($blog->name); ?>">
                                    </div>

                                </div>
                                <div class="content-box">

                                    <div class="content-art">
                                        <a href="<?php echo e(route('blog',$blog->slug)); ?>" class="section-heading-jost-size28">
                                            <?php echo e($blog->name); ?>

                                        </a>
                                        <p class="desc-content-box text-decs">
                                            <?php echo e(Str::limit(strip_tags(html_entity_decode($blog->content)), 200)); ?>

                                        </p>
                                        <div class="link-style2">
                                            <a href="<?php echo e(route('blog',$blog->slug)); ?>" class="read-more">
                                                Ətraflı<i class="fas fa-long-arrow-alt-right"></i>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="themesflat-pagination clearfix">
                            
                            <?php echo e($blogs->links()); ?>

                        </div>
                        <!-- end pagination-->
                    </div>
                    <!-- /.post-wrap -->
                </div>
                <!-- /.col-md-8 -->

                <div class="col-md-4">
                    <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="60" data-smobile="60"></div>
                    <div class="side-bar">
                        
                        <div class="widget widget_lastest">
                            <h2 class="widgets-side-bar-title"><span>Yeni Bloglar</span></h2>
                            <ul class="lastest-posts data-effect clearfix">
                                <?php $__currentLoopData = $recentBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="clearfix">
                                        <div class="thumb data-effect-item has-effect-icon">
                                            <img src="<?php echo e(_img($blog->avatar)); ?>" alt="<?php echo e($blg->name); ?>">
                                        </div>
                                        <div class="text">
                                            <h3><a href="<?php echo e(route('blog',$blg->slug)); ?>" class="title-thumb"><?php echo e(Str::limit(strip_tags(html_entity_decode($blg->content)), 50)); ?></a></h3>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                        <!-- /.widget_lastest -->
                        <div class="widgets-contact-info">
                            <div class="contact-info-img">
                                <img src="<?php echo e(_frontStaticImg('blog/young-beautiful-florist-watering-flowers.jpg')); ?>" alt="image">
                            </div>
                            <div class="contact-info-box">
                                <div class="contact-info-content">
                                    <div class="call-us">
                                        <div class="icon-call-us"></div>
                                        <div class="content-call-us">
                                            <h4 class="heading-16px-rubik">Əlaqə</h4>
                                            <h4 class="heading-16px-rubik"><?php echo e(_contact('phone')); ?></h4>
                                        </div>
                                    </div>
                                    <div class="our-mail">
                                        <div class="icon-our-mail"></div>
                                        <div class="content-our-mail">
                                            <h4 class="heading-16px-rubik">E-Poçt</h4>
                                            <h4 class="heading-16px-rubik"><?php echo e(_contact('email')); ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-md-4 -->
                </div>
                <!-- /.row -->
            </div>
        </div> <!-- /.container -->
    </section><!-- /flat-blog -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/pages/blogs.blade.php ENDPATH**/ ?>