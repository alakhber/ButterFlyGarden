
<?php $__env->startSection('_title'); ?>
| <?php echo e($blog->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_content'); ?>
    <!-- page title -->
    <div class="page-title">
        <div class="container-fluid">
            <div class="row">
                <div class="inner-title">
                    <div class="overlay-image"></div>
                    <div class="banner-title">
                        <div class="page-title-heading">
                            <?php echo e($blog->name); ?>

                        </div>
                        <div class="page-title-content link-style6">
                            <span><a class="home" href="<?php echo e(route('home')); ?>">Ana Səhifə</a></span> |
                            <span><a class="home" href="<?php echo e(route('blogs')); ?>">Bloglar</a></span>
                            <span class="page-title-content-inner"><?php echo e($blog->name); ?></span>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!-- /.page-title -->

    <!-- main content -->
    <section class="flat-blog-detail">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="166" data-mobile="0" data-smobile="0"></div>
                </div>
                <div class="col-md-8">
                    <div class="post-wrap">
                        <div class="content-blog-detail">
                            <div class="image-box">
                                <div class="image" style="width: 100%;height: 500px;">
                                    <img style="width: 100%;height: 100%; object-fit: cover" src="<?php echo e(_img($blog->avatar)); ?>" alt="<?php echo e($blog->avatar); ?>">
                                </div>
                            </div>
                            <div class="content mg-top-15">
                                
                                <div class="heading-content-box">
                                    <a href="<?php echo e(url()->current()); ?>">
                                        <?php echo e($blog->name); ?>

                                    </a>
                                </div>


                                <div class="desc-content-box text-decs">
                                    <?php echo $blog->content; ?> 
                                </div>
                                
                                


                                
                                <hr>
                                
                            </div>
                        </div>
                    </div>
                    <!-- /.post-wrap -->

                </div>
                <!-- /.col-md-8 -->

                <div class="col-md-4">
                    <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="60" data-smobile="60"></div>
                    <div class="side-bar">
                        <?php if(count($latestBlogs)>0): ?>
                        <div class="widget widget_lastest">
                            <h2 class="widgets-side-bar-title"><span>Son Bloglar</span></h2>
                            <ul class="lastest-posts data-effect clearfix">
                                <?php $__currentLoopData = $latestBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="clearfix">
                                        <div class="thumb data-effect-item has-effect-icon">
                                            <img src="images/blog/medium-shot-woman-holding-plant-pot.jpg" alt="<?php echo e($blg->name); ?>">
                                            <div class="elm-link">
                                                <a href="<?php echo e(route('blog',$blg->slug)); ?>" class="icon-2"></a>
                                            </div>
                                        </div>
                                        <div class="text">
                                            <h3><a href="<?php echo e(route('blog',$blg->slug)); ?>" class="title-thumb"><?php echo e($blg->name); ?></a></h3>
                                            
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        
                        <!-- /.widget_lastest -->
                        <div class="widgets-contact-info">
                            <div class="contact-info-img">
                                <img src="<?php echo e(_frontStaticImg('blog/young-beautiful-florist-watering-flowers.jpg')); ?>" alt="Contact">
                            </div>
                            <div class="contact-info-box">
                                <div class="contact-info-content">
                                    <div class="call-us">
                                        <div class="icon-call-us"></div>
                                        <div class="content-call-us">
                                            <div class="heading-16px-rubik">Tel</div>
                                            <div class="heading-16px-rubik"><?php echo e(_contact('phone')); ?></div>
                                        </div>
                                    </div>
                                    <div class="our-mail">
                                        <div class="icon-our-mail"></div>
                                        <div class="content-our-mail">
                                            <div class="heading-16px-rubik">E-Poçt</div>
                                            <div class="heading-16px-rubik"><?php echo e(_contact('email')); ?></div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-md-4 -->
                <div class="col-md-12">
                    <div class="themesflat-spacer clearfix" data-desktop="193" data-mobile="60" data-smobile="60"></div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </section>
    <!-- /.main-content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/pages/blog.blade.php ENDPATH**/ ?>