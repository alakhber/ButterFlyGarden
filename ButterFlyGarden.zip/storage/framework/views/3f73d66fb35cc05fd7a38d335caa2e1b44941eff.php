<head>
    <meta charset="UTF-8">
    <title><?php echo e(_setting('main_title')); ?> <?php echo $__env->yieldContent('_title'); ?></title>
    <meta name="author" content="Alakhber Nakhiyev">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
   <?php echo $__env->make('main.partials._styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/partials/_head.blade.php ENDPATH**/ ?>