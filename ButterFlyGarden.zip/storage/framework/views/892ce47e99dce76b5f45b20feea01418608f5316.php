
<?php $__env->startSection('title', 'Admin Dashboard | ' . $product->name . '| Qalerya '); ?>
<?php $__env->startSection('_styles'); ?>
    <link rel="stylesheet" href="https://v2.travels.az/adminlte/plugins/magify/magnific-popup.css">
    <link rel="stylesheet" href="https://v2.travels.az/adminlte/plugins/magify/user-card.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_scripts'); ?>
    <script src="<?php echo e(_adminJs('plugins/uploaders/fileinput/plugins/sortable.min.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('plugins/uploaders/fileinput/fileinput.min.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('demo_pages/uploader_bootstrap.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('plugins/notifications/pnotify.min.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(_adminJs('app.js')); ?>"></script>
    <!-- Theme JS files -->
    <script src="https://v2.travels.az/adminlte/plugins/jquery-ui/jquery-ui.js"></script>
    <script>
        $(function() {
            $("#sortable").sortable();
            $('#sortable').on("sortupdate", function(event, ui) {

                $(this).children().each(function(index) {
                    if ($(this).attr('data-position') != (index + 1)) {
                        $(this).attr('data-position', (index + 1)).addClass('updated');
                    }
                })
                saveNewPosition();
            });
            $("#sortable").disableSelection();

            function saveNewPosition() {
                let positions = [];
                $('#sortable > div').each(function() {
                    positions.push([$(this).attr('data-id'), $(this).attr('data-position')]);
                    $(this).removeClass('updated');
                })
                console.log(positions);
                $.ajax({
                    url: `<?php echo e(route('system.product.gallery.sortable', $product)); ?>`,
                    method: 'POST',
                    data: {
                        _token: `<?php echo e(csrf_token()); ?>`,
                        _method: 'PUT',
                        positions: positions
                    },
                    
                    success: function(response) {
                        new PNotify({
                            title: 'Uğurlu Əməliyyat',
                            text: `${response.msg}`,
                            icon: 'icon-checkmark3',
                            type: 'success'
                        });
                        setTimeout(() => {
                            Swal.hideLoading();
                        }, 1000);
                    }
                });

            }

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_content'); ?>
    <div class="page-header page-header-light">
        <div class="page-header-content d-sm-flex">
            <div class="page-title">
                <h4><span class="font-weight-semibold"><?php echo e($product->name); ?> Üçün Şəkillər</span></h4>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="breadcrumb-line breadcrumb-line-light header-elements-sm-inline">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('system.home')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Dashboard</a>
                    <a href="<?php echo e(route('system.product.index')); ?>" class="breadcrumb-item"> Məhsullar</a>
                    <span class="breadcrumb-item active"><?php echo e($product->name); ?></span>
                    <span class="breadcrumb-item active">Şəkilləri</span>
                </div>
                <a href="#" class="header-elements-toggle text-body d-sm-none"><i class="icon-more"></i></a>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('system.product.gallery.upload', $product)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <fieldset class="mb-3 row">
                        <legend class="text-uppercase font-size-sm font-weight-bold border-bottom">Şəkil Seç</legend>
                        <div class="col-lg-12">
                            <div class="form-group ">
                                <div class="col-lg-12">
                                    <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger pl-2"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="file" multiple class="file-input <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gallery[]" data-show-caption="false" data-show-upload="false" data-fouc>
                                </div>

                            </div>
                        </div>
                    </fieldset>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Yadda Saxla <i class="fas fa-save ml-2"></i></button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <fieldset class="mb-3 row">
                    <legend class="text-uppercase font-size-sm font-weight-bold border-bottom">Qalerya Sekilleri</legend>
                    <div class="row el-element-overlay" id='sortable'>
                        <?php $__empty_1 = true; $__currentLoopData = $product->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-4 col-md-6 list" data-id=<?php echo e($image->id); ?> data-position="1">
                                <div class="card">
                                    <div class="el-card-item pb-0">
                                        <div class="el-card-avatar el-overlay-1 mb-0">
                                            <img src="<?php echo e(_img($image->image)); ?>" style="width: 100%; height:300px; object-fit:contain" />
                                            <div class="el-overlay">
                                                <ul class="el-info">
                                                    <li><a class="btn default btn-outline image-popup-vertical-fit" href="<?php echo e(_img($image->image)); ?>"><i class="fas fa-search"></i></a></li>
                                                    <li>
                                                        <a title="Sil" href="javascript:void(0)" class="btn default btn-outline DELETEITEM "><i class="text-danger fas fa-trash"></i>
                                                            <form action="<?php echo e(route('system.product.gallery.delete', ['product' => $product, 'image' => $image])); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                            </form>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </div>

                </fieldset>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/product/gallery.blade.php ENDPATH**/ ?>