<div class="preloader">
    <div class="clear-loading loading-effect-2">
        <span></span>
    </div>
</div><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/main/partials/_loader.blade.php ENDPATH**/ ?>