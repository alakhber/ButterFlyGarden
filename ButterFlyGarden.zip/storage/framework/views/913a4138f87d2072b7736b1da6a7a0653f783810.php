<div class="navbar navbar-expand-lg navbar-light">
    <div class="text-center d-lg-none w-100">
        <button type="button" class="navbar-toggler dropdown-toggle" data-toggle="collapse" data-target="#navbar-footer">
            <i class="icon-unfold mr-2"></i>
            Footer
        </button>
    </div>
    <div class="navbar-collapse collapse" id="navbar-footer">
        <span class="navbar-text">
            &copy; 2015 - 2018. <a href="<?php echo e(url()->current()); ?>">ButterFlyGarden</a> by <a href="https://themeforest.net/user/Kopyov" target="_blank">Alakhber Nakhiyev</a>
        </span>

        
    </div>
</div>
<?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/partials/_footer.blade.php ENDPATH**/ ?>