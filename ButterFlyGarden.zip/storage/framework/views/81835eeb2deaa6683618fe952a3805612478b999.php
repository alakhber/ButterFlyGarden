
<?php $__env->startSection('title', 'Admin Dashboard | Qalerya '); ?>
<?php $__env->startSection('_styles'); ?>
    <link rel="stylesheet" href="https://v2.travels.az/adminlte/plugins/magify/magnific-popup.css">
    <link rel="stylesheet" href="https://v2.travels.az/adminlte/plugins/magify/user-card.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_scripts'); ?>
    <script src="<?php echo e(_adminJs('plugins/uploaders/fileinput/plugins/sortable.min.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('plugins/uploaders/fileinput/fileinput.min.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('demo_pages/uploader_bootstrap.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('plugins/notifications/pnotify.min.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(_adminJs('app.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('clipboard.min.js')); ?>"></script>
    <script src="<?php echo e(_adminJs('plugins/notifications/pnotify.min.js')); ?>"></script>

    <script>
        var clipboard = new ClipboardJS('.copy');
        clipboard.on('success', function(e) {
            new PNotify({
                title: 'Uğurlu Əməliyyat',
                text: 'Şəkil Uğurla Kopyalandı.İstənilən CTRL-V ilə Əlavə Edə Bilərsiniz',
                icon: 'icon-checkmark3',
                type: 'success'
            });
        });

        clipboard.on('error', function(e) {
            new PNotify({
                title: 'Uğursuz Əməliyyat',
                text: 'Şəkil Kopyalanan Zaman Xəta Baş Verdi.Biraz Sonra Yenidən Yoxlayın',
                icon: 'icon-checkmark3',
                type: 'error'
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_content'); ?>
    <div class="page-header page-header-light">
        <div class="page-header-content d-sm-flex">
            <div class="page-title">
                <h4><span class="font-weight-semibold">Qalerya</span></h4>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="breadcrumb-line breadcrumb-line-light header-elements-sm-inline">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('system.home')); ?>" class="breadcrumb-item"><i class="icon-home2 mr-2"></i> Dashboard</a>
                    <a href="<?php echo e(route('system.image.index')); ?>" class="breadcrumb-item"> Qalerya</a>

                </div>
                <a href="#" class="header-elements-toggle text-body d-sm-none"><i class="icon-more"></i></a>
            </div>
        </div>
    </div>
    <div class="content">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('system.image.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <fieldset class="mb-3 row">
                        <legend class="text-uppercase font-size-sm font-weight-bold border-bottom">Şəkil Seç</legend>
                        <div class="col-lg-12">
                            <div class="form-group ">
                                <div class="col-lg-12">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger pl-2"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <input type="file" multiple class="file-input <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>  is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image[]" data-show-caption="false" data-show-upload="false" data-fouc>
                                </div>

                            </div>
                        </div>
                    </fieldset>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Yadda Saxla <i class="fas fa-save ml-2"></i></button>
                    </div>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <fieldset class="mb-3 row">
                    <legend class="text-uppercase font-size-sm font-weight-bold border-bottom">Qalerya Sekilleri</legend>
                    <div class="row el-element-overlay" id='sortable'>
                        <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-4 col-md-6 list" data-id=<?php echo e($image->id); ?> data-position="1">
                                <div class="card">
                                    <div class="el-card-item pb-0">
                                        <div class="el-card-avatar el-overlay-1 mb-0">
                                            <img src="<?php echo e(_img($image->image)); ?>" style="width: 100%; height:300px; object-fit:contain" />
                                            <div class="el-overlay">
                                                <ul class="el-info">
                                                    <li><a class="btn default btn-outline image-popup-vertical-fit copy" title="Kopyala" data-clipboard-action="copy" data-clipboard-target="#image-<?php echo e($image->id); ?>" href="javascript:void(0)"><i class="fas fa-link"></i></a></li>
                                                    <input type="hidden" value="<?php echo e(_asset(_img($image->image))); ?>" id="image-<?php echo e($image->id); ?>">
                                                    <li><a class="btn default btn-outline image-popup-vertical-fit" title="Bax" href="<?php echo e(_img($image->image)); ?>"><i class="fas fa-search"></i></a></li>
                                                    <li>
                                                        <a title="Sil" href="javascript:void(0)" class="btn default btn-outline DELETEITEM "><i class="text-danger fas fa-trash"></i>
                                                            <form action="<?php echo e(route('system.image.delete', $image)); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                            </form>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </div>

                </fieldset>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Desktop\ButterFlyGarden\resources\views/control/gallery/index.blade.php ENDPATH**/ ?>