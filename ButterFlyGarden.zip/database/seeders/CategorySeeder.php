<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Category::create([
            'name'=>'Əsas Kateqorya',
            'slug'=>'main',
        ]);

        for ($i=1; $i <15 ; $i++) { 
            $categoryID = Category::all()->pluck('id')->toArray();
            
            Category::create([
                'category_id'=>$categoryID[array_rand($categoryID, 1)],
                'name'=>'Kataloq '.$i,
                'slug'=>_slug('Kataloq '.$i)
            ]);
        }
    }
}
